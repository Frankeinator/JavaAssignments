/*
Name: Alex Franke
Q: 4
 */
public class TextQuote {
    public static void main(String[] args) {
        System.out.println("Hearing in the distance\n\n");
        System.out.println("Two mandolins like creatures in the\n\n");
        System.out.println("dark\n\n");
        System.out.println("Creating the agony of ecstasy.\n\n");
        System.out.println(" - George Barker");
    }
}
