/*
Name: Alex Franke
Q: 5
 */
public class Franke {
    public static void main(String[] args)
    {
        System.out.println("Alex Franke\n123 Main St. Columbia, MO 65201\n660-555-0205\nComputer Science");
    }
}
